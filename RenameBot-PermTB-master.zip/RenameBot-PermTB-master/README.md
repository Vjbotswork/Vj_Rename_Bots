## Rename Bot 

An Open Source Telegram Rename Bot

---
Rename any Telegram Files with Permanent Thumbnail Support

* Added auto detect of files


### Installation


### You can tap the Deploy To Heroku button below to deploy straight to Heroku!
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/prgofficial/RenameBot-PermTB)

### Deploy in your vps
```sh
git clone https://github.com/prgofficial/RenameBot-PermTB
cd RenameBot-PermTB
virtualenv -p python3 VENV
. ./VENV/bin/activate
pip install -r requirements.txt
# <Create config.py appropriately>
python3 -m tobrot
```


#### For Queries and support, contact [prgofficial](https://telegram.dog/prgofficial)

## Credits, and Thanks to Beloved Developers ;

* [SpEcHlDe](https://telegram.dog/SpEcHlDe) 
* [Dan Tès](https://telegram.dog/haskell) 
* [Yoily](https://telegram.dog/YoilyL)
* [Anand](https://telegram.dog/Anandpskerala)
